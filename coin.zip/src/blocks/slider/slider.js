$('.slider').slick({
  infinite: false,
  initialSlide: $('.slider__item').length
});