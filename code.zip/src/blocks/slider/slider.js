$('.slider').slick({
  infinite: false,
  initialSlide: 3
});